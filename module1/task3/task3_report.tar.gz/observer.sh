#!/bin/bash

CONFIG_FILE="observer.conf"
LOG_FILE="observer.log"

if [ ! -f "$CONFIG_FILE" ]; then
    echo "Конфигурационный файл $CONFIG_FILE не найден"
    exit 1
fi

while read -r script; do
    if [ -z "$script" ]; then
        continue
    fi

    if pgrep -f "$script" > /dev/null; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') $script уже запущен" >> "$LOG_FILE"
    else
        echo "$(date '+%Y-%m-%d %H:%M:%S') Запуск $script" >> "$LOG_FILE"
        nohup "./$script" > /dev/null 2>&1 &
    fi
done < "$CONFIG_FILE"
