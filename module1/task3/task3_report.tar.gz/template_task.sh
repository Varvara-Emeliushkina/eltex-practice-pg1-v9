#!/bin/bash

SCRIPT_NAME=$(basename "$0" .sh)

if [ "$SCRIPT_NAME" = "template_task" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

LOG_FILE="report_${SCRIPT_NAME}.log"
echo "[$$] $(date '+%Y-%m-%d %H:%M:%S') Скрипт запущен" >> "$LOG_FILE"

RAND_SECONDS=$((30 + RANDOM % 1771))
sleep $RAND_SECONDS

MINUTES=$((RAND_SECONDS / 60))
echo "[$$] $(date '+%Y-%m-%d %H:%M:%S') Скрипт завершился, работал $MINUTES минут" >> "$LOG_FILE"


